let a = 5;

function test() {
    console.log(a);
    //let a = 10;
}
test();