(function (firstName) {
    ///block code
    console.log("welcome " + firstName);
})("Laurence");
let result = (function () {
    return "Hello World";
});
console.log(result());