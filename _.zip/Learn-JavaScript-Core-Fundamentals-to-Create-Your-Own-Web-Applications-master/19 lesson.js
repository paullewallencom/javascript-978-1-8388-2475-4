let person = "Laurence";
switch (person) {
case "John":
    console.log(person + " is not my friend");
    break;
case "Laurence":
    console.log("found it");
    break;
case "Steve":
    console.log("hi Steve");
    break;
default:
    console.log("Nobody found");
}