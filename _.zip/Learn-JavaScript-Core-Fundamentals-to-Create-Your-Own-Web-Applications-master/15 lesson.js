let checkNum = "10";
if (checkNum > 10) {
    console.log("yes greater than 10");
}
else if (checkNum === 10) {
    console.log("they are equal");
}
else {
    console.log("that was false");
}