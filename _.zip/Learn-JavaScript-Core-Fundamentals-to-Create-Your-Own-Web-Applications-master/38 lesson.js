for (let counter = 1; counter < 6; counter++) {
    console.log("for loop" + counter);
}
let x = 10;
while (x < 5) {
    console.log("while loop" + x);
    x++;
}
let i = 10;
do {
    console.log("do while" + i);
    i++;
} while (i < 5);