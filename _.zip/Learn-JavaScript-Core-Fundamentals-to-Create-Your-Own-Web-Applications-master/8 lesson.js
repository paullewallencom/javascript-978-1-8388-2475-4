let userName = prompt("what is you name?");
let message = "Welcome to my site ";
console.log(message + userName);