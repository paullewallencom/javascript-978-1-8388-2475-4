let myNum = "100";
myNum = Number(myNum);
console.log(myNum);
console.log(typeof myNum);

let a = Number("5");
let b = Number("10");
console.log(a+b);