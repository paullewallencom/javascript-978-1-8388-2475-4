const myCar = {};
myCar.color = "black";
console.log(myCar);
myCar["year"] = "2019";
console.log(myCar);
const car = {
    color: 'red'
    , year: 2010
    , make: 'Corvette'
    , brand: 'Chevrolet'
    , price: 50000
};
let a = 1;
const test = {
    a1: "test 1"
    , a2: "test 2"
}
console.log(test);