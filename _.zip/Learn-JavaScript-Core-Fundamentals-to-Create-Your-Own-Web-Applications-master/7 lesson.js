const test = false;
let message = "Welcome to the website";
let moreStuff;
if(test){
    console.log(message);
    moreStuff = "Yes content is here";
    let inBlock = "this is secret within the block";
    console.log(inBlock);
}
console.log(moreStuff);