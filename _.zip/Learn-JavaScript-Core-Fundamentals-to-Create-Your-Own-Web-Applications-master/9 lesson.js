let userName = prompt("What is your name?");
let message = `Welcome 
${userName}`;
console.log(message);