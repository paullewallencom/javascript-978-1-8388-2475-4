let checkNum = "5";
if (checkNum) {
    console.log("checknum is true");
}
if (checkNum > 50) {
    console.log("Its bigger than 50");
}
if (checkNum === 5) {
    console.log("yes");
}
console.log(checkNum);