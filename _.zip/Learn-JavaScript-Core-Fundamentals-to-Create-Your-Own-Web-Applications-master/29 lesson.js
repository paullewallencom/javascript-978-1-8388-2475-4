var test = function (x) {
    return x * 10;
}
const test2 = (x) => x * 10;
console.log(test(90));
console.log(test2(90));