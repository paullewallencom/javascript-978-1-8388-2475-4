let test1 = function (num) {
    return num + 5;
}
console.log(test1(5));
console.log(test2(5));

function test2(num) {
    return num + 5;
}