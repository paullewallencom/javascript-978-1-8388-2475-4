var a = "hello world";
console.log(a);
a = "Welcome Back";
console.log(a);

var myName = "Laurence";
console.log(myName);
myName = "John";
console.log(myName);