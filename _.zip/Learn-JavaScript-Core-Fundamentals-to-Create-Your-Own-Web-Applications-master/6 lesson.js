let message;
console.log(message);
message = null;
if(true){
    let message = "updated message";
    console.log(message);
}
console.log(message);