var a = "hello world"; // this was a test variable
console.log(a);
/*
I enjoy working with JavaScript

*/