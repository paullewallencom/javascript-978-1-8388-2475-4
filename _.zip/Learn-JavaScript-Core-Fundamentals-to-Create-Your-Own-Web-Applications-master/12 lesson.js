let firstNum = 5;
let secNum = 10;
firstNum++;
secNum--;
let total = firstNum + secNum;
console.log(total);
total = 500 + 100 / 5 + total;
console.log(total);
