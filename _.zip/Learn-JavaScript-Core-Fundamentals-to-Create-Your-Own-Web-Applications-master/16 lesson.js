let val = 12211212;
let status = (val % 2) ? "odd" : "even";
console.log(val);
console.log(status);